Field Reports 1.5.2 PHP Bridge
==============================

はじめに
--------

Field Reports PHP Bridge（以降，本モジュールと表記します）は，PDF帳票ツール
Field ReportsをPHPから利用するための拡張モジュールです。

このREADMEファイルでは，本モジュールをインストールし，お使いになる上で必要な手
順を簡易に記述してあります。

Field Reports本体ならびに本モジュールの詳しいインストール手順／使い方について
は，同梱の「ユーザーズ・マニュアル(users-man.pdf)」を参照してください。また，
Field Reportsに関する最新情報は，弊社Webサイトを参照してください::

    http://field-works.co.jp/

機能説明
--------

PHPから Field Reports のPDF帳票生成機能を利用することができます。

APIを通じて，以下の機能を提供します。

* Field Reportsのバージョンを取得する。

* ログ出力のレベルを設定する。

* PDFを生成し，結果をバイナリ文字列として受け取る。

* PDFを生成し，結果をファイルに出力する。

API概要
-------
::

    // バージョン番号を取得します。
    string fr_version();

    // ログ出力のレベルを設定します。
    // 有効な値の範囲は0〜4です:
    //  0: ログを出力しない
    //  1: ERRORログを出力する
    //  2: WARNログを出力する
    //  3: INFOログを出力する
    //  4: DEBUGログを出力する
    // 1以上の値を設定した場合，標準エラー出力にログを出力します（初期値：0）。
    void fr_set_log_level(int $loglevel);

    // レンダリング・パラメータのデフォルト値を設定します。
    // $param の型が配列の場合は，レンダリング・パラメータがPHPネイティブの
    // データ・オブジェクトで表現されているものとします。$param が文字列の場合
    // は，JSON形式の文字列で記述されているものとします。
    // 文字列のエンコーディングはUTF-8としてください。
    void fr_set_defaults(mixed $param);

    // レンダリング・パラメータ$param を元にレンダリングを実行し，結果をバイト
    // 文字列として返します。$param の型として配列または文字列を受け付けます。
    string fr_renders(mixed $param);

    // レンダリング・パラメータ$param を元にレンダリングを実行します。
    // 処理結果は，$filename で指定したファイルに出力されます。$param の型として
    // 配列または文字列を受け付けます。
    void fr_render(mixed $param, string $filename);

必要条件
--------

本モジュールをインストールする前に，Field Reports本体のインストールが完了して
いる必要があります。

また，本モジュールのインストールには，以下のソフトウェアが必要です。

* PHP 5.2以降

インストール手順
----------------

Linux，Mac OS X用のPHP Bridgeは，ソース提供のみとなります。
ユーザーズ・マニュアル「言語Bridgeのビルド手順」をご参照ください。

Windows用のバイナリ配布物をインストールする手順は，以下のとおりです。

拡張モジュールのインストール
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

動作環境でのPHPのバージョンに対応したディレクトリにある
“php_reports_ts.dll”（スレッドセーフ）または“php_reportss.dll”（非スレッド
セーフ）ファイルをPATHが通った場所へコピーしてください。

    copy php_reports_ts.dll <拡張モジュール格納場所>

PHP設定ファイル(php.ini)の編集
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

php.iniを編集して，次の行を追加してください::

    extension = php_reports_ts.dll

環境設定
~~~~~~~~

必要に応じて，環境変数'PATH'に共有ライブラリの検索パスを追加してください::

    set PATH=%PROGRAMFILES%\Field Works\Field Reports x.x\bin;%PATH%

ライセンス
----------

本モジュールのソースコードは，BSDライセンスのオープンソースとします。

例えば以下のような場合，自由に改変／再配布していただいて結構です。

* ビルド環境の違いにより，モジュールのロードエラー等が発生した。

* 未サポートのPHPバージョンへの対応のため改造が必要。

* 他の言語の拡張ライブラリ作成のベースとして利用したい。

ただし，ソースを改変したモジュール自体において問題が発生し場合については，サ
ポート対応いたしかねますのでご了承ください（Field Reports本体の問題であれば対
応いたします）。


Copyright 2011-2014 Field Works, LLC.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name of the Field Works, LLC. nor the names of its contributors
  may be used to endorse or promote products derived from this software
  without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


