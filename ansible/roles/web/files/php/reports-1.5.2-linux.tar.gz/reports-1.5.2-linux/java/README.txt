Field Reports 1.5.2 Java Bridge
===============================

はじめに
--------

Field Reports Java Bridge（以降，本モジュールと表記します）は，PDF帳票ツール
Field ReportsをJava(JVM)から利用するための拡張モジュールです。

このREADMEファイルでは，本モジュールをインストールし，お使いになる上で必要な手
順を簡易に記述してあります。

Field Reports本体ならびに本モジュールの詳しいインストール手順／使い方について
は，同梱の「ユーザーズ・マニュアル(users-man.pdf)」を参照してください。また，
Field Reportsに関する最新情報は，弊社Webサイトを参照してください::

    http://field-works.co.jp/

機能説明
--------

JavaもしくはJVM上で動作するプログラミング言語から Field Reports のPDF帳票生成
機能を利用することができます。

APIを通じて，以下の機能を提供します。

* Field Reportsのバージョンを取得する。

* ログ出力のレベルを設定する。

* PDFを生成し，結果をバイナリ文字列として受け取る。

* PDFを生成し，結果をファイルに出力する。

API概要
-------
::
    import jp.co.field_works.Reports;
    import jp.co.field_works.ReportsException;

    /**
     * バージョン番号を取得します。
     */
    public static String version() throws ReportsException;
    
    /**
     * ログ出力のレベルを設定します。
     * 有効な値の範囲は0〜4です:
     *  0: ログを出力しない
     *  1: ERRORログを出力する
     *  2: WARNログを出力する
     *  3: INFOログを出力する
     *  4: DEBUGログを出力する
     * 1以上の値を設定した場合，標準エラー出力にログを出力します（初期値：0）。
     */
    public static void setLogLevel(int n) throws ReportsException;

    /**
     * レンダリング・パラメータのデフォルト値を設定します。
     * レンダリング・パラメータは，JSON形式の文字列で与えます。
     */
    public static void setDefaults(String param) throws ReportsException;

    /**
     * レンダリング・パラメータparamを元にレンダリングを実行し，
     * 結果をバイト文字列として返します。
     * レンダリング・パラメータは，JSON形式の文字列で与えます。
     */
    public static byte[] renders(String param) throws ReportsException;

    /**
     * レンダリング・パラメータparamを元にレンダリングを実行します。
     * 処理結果は，filenameで指定したファイルに出力されます。
     * レンダリング・パラメータは，JSON形式の文字列で与えます。
     */
    public static void render(String param, String filename)
        throws ReportsException;

必要条件
--------

本モジュールをインストールする前に，Field Reports本体のインストールが完了して
いる必要があります。

また，本モジュールを動作させるには，以下のソフトウェアが必要です。

* JDK1.6

インストール手順
----------------

JDKをインストールし，環境変数'JAVA_HOME'にJDKのインストール先ディレクトリを設定
した上で，jarファイルとJNIライブラリを拡張ライブラリの格納場所にコピーしてくだ
さい。

jarファイルのインストール
~~~~~~~~~~~~~~~~~~~~~~~~~

ご使用になるJDKのバージョンに適したjarファイルをjarファイルの格納場所にコピーし
てください。

* <JDKバージョン>/reports.jar

jarファイルの格納場所は以下のとおりです。

* $JAVA_HOME/jre/lib/ext（Linux環境）

* /Library/Java/Extensions（Mac OS X環境）

* %JAVA_HOME%\jre\lib\ext（Windows環境）

JNIライブラリのインストール
~~~~~~~~~~~~~~~~~~~~~~~~~~~

ご使用になるJDKのバージョンとアーキテクチャに適したネイティブ・ライブラリを
JNIライブラリの格納場所にコピーしてください。

* <JDKバージョン>/<アーキテクチャ>/libReports.so (Linux環境）

* <JDKバージョン>/<アーキテクチャ>/libReports.jnilib (Mac OS X環境)

* <JDKバージョン>\<アーキテクチャ>\Reports.dll (Windows環境)

JNIライブラリの格納場所は以下のとおりです。

* $JAVA_HOME/jre/lib/<アーキテクチャ>（Linux環境）

* /Library/Java/Extensions（Mac OS X環境）

* %JAVA_HOME%\jre\bin（Windows環境）

ライセンス
----------

本モジュールのソースコードは，BSDライセンスのオープンソースとします。

例えば以下のような場合，自由に改変／再配布していただいて結構です。

* ビルド環境の違いにより，モジュールのロードエラー等が発生した。

* 未サポートのJDKバージョンへの対応のため改造が必要。

* 他の言語の拡張ライブラリ作成のベースとして利用したい。

ただし，ソースを改変したモジュール自体において問題が発生し場合については，サ
ポート対応いたしかねますのでご了承ください（Field Reports本体の問題であれば対
応いたします）。


Copyright 2011-2014 Field Works, LLC.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name of the Field Works, LLC. nor the names of its contributors
  may be used to endorse or promote products derived from this software
  without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


