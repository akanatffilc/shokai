Field Reports 1.5.2 Python Bridge
=================================

はじめに
--------

Field Reports Python Bridge（以降，本モジュールと表記します）は，PDF帳票ツール
Field ReportsをPythonから利用するための拡張モジュールです。

このREADMEファイルでは，本モジュールをインストールし，お使いになる上で必要な手
順を簡易に記述してあります。

Field Reports本体ならびに本モジュールの詳しいインストール手順／使い方について
は，同梱の「ユーザーズ・マニュアル(users-man.pdf)」を参照してください。また，
Field Reportsに関する最新情報は，弊社Webサイトを参照してください::

    http://field-works.co.jp/

機能説明
--------

PythonからField ReportsのPDF帳票生成機能を利用することができます。

APIを通じて，以下の機能を提供します。

* Field Reportsのバージョンを取得する。

* ログ出力のレベルを設定する。

* PDFを生成し，結果をバイナリ文字列として受け取る。

* PDFを生成し，結果をファイルに出力する。

API概要
-------
::

    import field.reports

    # バージョン番号を取得します。
    field.reports.version()

    # ログ出力のレベルを設定します。
    # 有効な値の範囲は0〜4です:
    #  0: ログを出力しない
    #  1: ERRORログを出力する
    #  2: WARNログを出力する
    #  3: INFOログを出力する
    #  4: DEBUGログを出力する
    # 1以上の値を設定した場合，標準エラー出力にログを出力します（初期値：0）。
    field.reports.set_log_level(<loglevel>)

    # レンダリング・パラメータのデフォルト値を設定します。
    # <param>の型が辞書の場合は，レンダリング・パラメータがPythonネイティブの
    # データ・オブジェクトで表現されているものとします。<param>が文字列の場合
    # は，JSON形式の文字列で記述されているものとします。バイト文字列を使用する
    # 場合は，エンコーディングをUTF-8としてください。
    field.reports.set_defaults(<param>)

    # レンダリング・パラメータ<param>を元にレンダリングを実行し，結果をバイト
    # 文字列として返します。<param>の型として辞書または文字列を受け付けます。
    field.reports.renders(<param>)

    # レンダリング・パラメータ<param>を元にレンダリングを実行します。
    # 処理結果は，<filename>で指定したファイルに出力されます。<param>の型として
    # 辞書または文字列を受け付けます。
    field.reports.render(<param>, <filename>)

必要条件
--------

本モジュールをインストールする前に，Field Reports本体のインストールが完了して
いる必要があります。

また，本モジュールのインストールには，以下のソフトウェアが必要です。

* Python 2.6以降
* Setuptools または Distribute（Windowsの場合は不要）

インストール手順
----------------

拡張モジュールのインストール(Linux/Mac OS X)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

管理者権限で，以下のコマンドを実行してください::

    easy_install -N field.reports-x.x-pyx.x-*.egg

拡張モジュールのインストール(Windows)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

管理者権限で，以下のコマンドを実行してください::

    field.reports-x.x.win32-pyx.x.exe

環境設定(Linux)
~~~~~~~~~~~~~~~

必要に応じて，環境変数'LD_LIBRARY_PATH'に共有ライブラリの検索パスを追加してくだ
さい::

    export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH

もしくは‘/etc/ld.so.conf’，‘/etc/ld.so.conf.d/\*.conf’等にパスを追加した上
で，ldconfigを実行してください。

環境設定(Mac OS X)
~~~~~~~~~~~~~~~~~~

必要に応じて，環境変数'DYLD_FALLBACK_LIBRARY_PATH'に共有ライブラリの検索パスを
追加してください::

    export DYLD_FALLBACK_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH

環境設定(Windows)
~~~~~~~~~~~~~~~~~~

必要に応じて，環境変数'PATH'に共有ライブラリの検索パスを追加してください::

    set PATH=%PROGRAMFILES%\Field Works\Field Reports x.x\bin;%PATH%

ライセンス
----------

本モジュールのソースコードは，BSDライセンスのオープンソースとします。

例えば以下のような場合，自由に改変／再配布していただいて結構です。

* ビルド環境の違いにより，モジュールのロードエラー等が発生した。

* 未サポートのPythonバージョンへの対応のため改造が必要。

* 他の言語の拡張ライブラリ作成のベースとして利用したい。

ただし，ソースを改変したモジュール自体において問題が発生し場合については，サ
ポート対応いたしかねますのでご了承ください（Field Reports本体の問題であれば対
応いたします）。


Copyright 2011-2014 Field Works, LLC.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above copyright notice, this
  list of conditions and the following disclaimer.

* Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

* Neither the name of the Field Works, LLC nor the names of its contributors
  may be used to endorse or promote products derived from this software
  without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

