Field Reports 1.5.2 C I/F
=========================

じめに
--------

このREADMEファイルでは，Field ReportsのC I/Fについて記述しています。

Field Reportsのインストール手順／使い方については，同梱の「ユーザーズ・マニュア
ル(users-man.pdf)」を参照してください。また，Field Reportsに関する最新情報は，
弊社Webサイトを参照してください::

    http://field-works.co.jp/

機能説明
--------

C I/Fを通じてField ReportsのPDF帳票生成機能を利用することができます。

以下の機能を提供します。

* Field Reportsを初期化する。

* Field Reportsのバージョンを取得する。

* ログ出力のレベルを設定する。

* レンダリング・パラメータのデフォルト値を設定する。

* JSON文字列をJSONオブジェクト（内部形式）に変換する。

* PDFを生成し，結果をバイナリ文字列として受け取る。

* PDFを生成し，結果をファイルに出力する。

API一覧
-------

APIの概要を示します。

なお，各言語Bridgeのソースファイルを公開していますので，APIの使用例として参照
してください。::

void rp_init(void)
    Field Reports を初期化します。
    最初に一度だけ呼び出してください。

caml_value* rp_version(void)
    Field Reports のバージョンを文字列で取得します。
    返り値：OCaml文字列。

caml_value* rp_set_log_level(value n)
    ログ出力のレベルを整数で設定します。
    引数 n として有効な値の範囲は0〜4です（0: ログを出力しない，1: ERRORログを
    出力する，2: WARN ログを出力する，3: INFO ログを出力する，4: DEBUG ログを
    出力する)。 1以上の値を設定した場合，標準エラー出力にログを出力します。初
    期値:0。返り値：なし。

caml_value* rp_set_defaults(caml_value* param)
    レンダリング・パラメータのデフォルト値を設定します。
    引数 jsons には，レンダリングパラメータをJSONオブジェクトとして渡します。
    返り値：なし。

caml_value* rp_pdf_of_json(caml_value* param)
    引数で与えたレンダリングパラメータを元にPDF帳票のレンダリングを行います。
    結果は，OCaml文字列として返されます。引数jsonには，OCaml形式のJSONオブジェ
    クトとして，レンダリングパラメータを渡します。返り値：OCaml文字列。

caml_value* rp_write_pdf_from_json(caml_value* param, const char* filename)
    引数で与えたレンダリングパラメータを元にPDF帳票のレンダリングを行います。
    結果は，引数filenameで与えたファイル名のファイルを作成して出力します。引数
    jsonには，OCaml形式のJSONオブジェクトとして，レンダリングパラメータを渡し
    ます。返り値：なし。

caml_value* rp_encode_json(rp_callback* cb, rp_val v)
    プログラミング言語固有のデータオブジェクトをOCaml形式のJSONオブジェクトに
    変換します。cbには，データ型を判定したり，データ変換を行うためのコールバッ
    ク関数を登録します。返り値：OCaml形式JSONオブジェクト。

caml_value* rp_json_of_string(const char* param)
    JSON文字列をOCaml形式のJSONオブジェクトに変換します。
    返り値：JSONオブジェクト。

void rp_free(caml_value* val)
    OCaml形式のデータオブジェクトを開放します。

int rp_is_error(caml_value* val)
    OCaml形式のデータオブジェクトを元に例外の発生有無を判定します。
    戻り値：真偽値（0：正常終了，0以外：例外発生）。

const char* rp_get_error(caml_value* val, int* err, char* msg)
    例外オブジェクトからエラー情報を抽出します。
    引数valには，各APIの返り値を渡します。errにはエラー番号，msgにはエラーメッ
    セージ，返り値にはエラーの種別を示す文字列（タグ）が設定されます。msgに
    は，呼び出し側でRP_MAX_ERR_MSG_LENバイト以上の文字列バッファを確保してくだ
    さい。

unsigned int rp_get_string_val(caml_value* val, char* buf)
    OCaml文字列より，C形式のバイト文字列を抽出します。
    引数valには，OCaml文字列のポインタを設定します。引数bufで指定した文字列
    バッファにバイト文字列がコピーされ，返り値には文字列バッファに必要なサイズ
    （バイト数）が返されます。bufにNULLを設定すると，必要なサイズのみ取得でき
    ます。

caml_value型について
~~~~~~~~~~~~~~~~~~~~

caml_valueは，Objective Caml(OCaml) オブジェクトを格納するための型です。

各APIの返り値として受け取ったOCamlオブジェクトは，呼び出し元の責任でrp_free()
を使って解放する必要があります。各APIの処理中にエラー（例外）が発生した場合
は，戻り値としてOCaml形式の例外オブジェクトが返されます。処理結果がエラーかど
うかを判定するには，rp_is_error()関数を使用してください。

OCamlとCとのインターフェースについての詳細は，OCamlユーザーズ・マニュアルを参照
してください(http://caml.inria.fr/pub/docs/manual-ocaml/index.html)。

コールバック関数について
~~~~~~~~~~~~~~~~~~~~~~~~

rp_encode_json()関数の引数として，以下に示すコールバック関数を格納した構造体へ
のポインタを設定します::

typedef int (*t_fn_type)(rp_val v);
typedef int (*t_fn_val_bool)(rp_val v, rp_val* opt);
typedef int (*t_fn_val_int)(rp_val v, rp_val* opt);
typedef double (*t_fn_val_float)(rp_val v, rp_val* opt);
typedef char* (*t_fn_val_string)(rp_val v, rp_val* opt);
typedef rp_pos (*t_fn_array_head)(rp_val v, rp_val* opt);
typedef int (*t_fn_array_next)(rp_val v, rp_pos* pos, rp_val* entry, rp_val* opt);
typedef rp_pos (*t_fn_object_head)(rp_val v, rp_val* opt);
typedef int (*t_fn_object_next)(rp_val v, rp_pos* pos, char** key, rp_val* entry, rp_val* opt);
typedef void (*t_fn_release)(rp_val opt);

typedef struct {
    t_fn_type fn_type;
    t_fn_val_bool fn_val_bool;
    t_fn_val_int fn_val_int;
    t_fn_val_float fn_val_float;
    t_fn_val_string fn_val_string;
    t_fn_array_head fn_array_head;
    t_fn_array_next fn_array_next;
    t_fn_object_head fn_object_head;
    t_fn_object_next fn_object_next;
    t_fn_release fn_release;
} rp_callback;

rp_valは変換元データオブジェクトへのポインタを格納するための型であり，rp_posは
配列・辞書型オブジェクトを列挙する際の位置情報を格納するための型です。

各コールバック関数の定義は以下のとおりです::

int fn_type(rp_val v)
    変換元データオブジェクトvの型を判定します。返り値：列挙値（NULL型：
    RP_TYPE_NULL，真偽型：RP_TYPE_BOOL，整数型：RP_TYPE_INT，実数型：
    RP_TYPE_FLOAT，文字列型：RP_TYPE_STRING，配列型：RP_TYPE_ARRAY，辞書型：
    RP_TYPE_OBJECT，その他：RP_TYPE_OTHER）。RP_TYPE_OTHERを返すと，データ変換
    処理は失敗し変換処理を中断します。
    
int fn_val_bool(rp_val v, rp_val* opt)
    変換元データオブジェクトvの真偽値としての値を取得します。optには，メモリ解
    放などの後処理が必要なオブジェクトへのポインタをセットします。後処理が不要
    な場合はNULLをセットします。返り値：真偽値（0：偽，0以外：真）。

int fn_val_int(rp_val v, rp_val* opt)
    変換元データオブジェクトvの整数としての値を取得します。optには，後処理が必
    要なオブジェクトへのポインタをセットします。返り値：整数値。

double fn_val_float(rp_val v, rp_val* opt)
    変換元データオブジェクトvの実数としての値を取得します。optには，後処理が必
    要なオブジェクトへのポインタをセットします。返り値：実数値。

char* fn_val_string(rp_val v, rp_val* opt)
    変換元データオブジェクトvの文字列としての値を取得します。optには，後処理が
    必要なオブジェクトへのポインタをセットします。返り値：文字配列へのポイン
    タ。

rp_pos fn_array_head(rp_val v, rp_val* opt)
    配列型データオブジェクトvの先頭位置を取得します。optには，メモリ解放などの
    後処理が必要なオブジェクトへのポインタをセットします。返り値：位置情報。

int fn_array_next(rp_val v, rp_pos* pos, rp_val* entry, rp_val* opt)
    配列型データオブジェクトvの現在位置の値を取得し，entryにセットします。現在
    位置をひとつ進め，posにセットします。進めます。位置情報が最後の位置を超え
    た場合，posにNULLをセットし，返り値に0（偽）を返します。optには，後処理が
    必要なオブジェクトへのポインタをセットします。返り値：真偽値（0：偽，0以
    外：真）。

rp_pos fn_object_head(rp_val v, rp_val* opt)
    辞書型データオブジェクトvの先頭位置を取得します。optには，後処理が必要なオ
    ブジェクトへのポインタをセットします。返り値：位置情報。

int fn_object_next(rp_val v, rp_pos* pos, char** key, rp_val* entry, rp_val* opt)
    辞書型データオブジェクトvの現在位置の値を取得し，entryにセットします。現在
    位置をひとつ進め，posにセットします。進めます。位置情報が最後の位置を超え
    た場合，posにNULLをセットし，返り値に0（偽）を返します。optには，後処理が
    必要なオブジェクトへのポインタをセットします。返り値：真偽値（0：偽，0以
    外：真）。

void fn_release(rp_val opt)
    optの後処理を行います。optがNULLの場合にもfn_release()は呼び出されます。


必要条件
--------

C I/Fを利用したプログラムをコンパイル・リンクする前に，Field Reports本体の
インストールを行う必要があります。

Linux, Mac OS Xでのリンク時には，共有ライブラリ‘libreports’をリンク指定して
ください（オプション‘-lreports’等を付加）。

ライセンス
----------

「ソフトウェア使用許諾契約書」をご参照ください。

