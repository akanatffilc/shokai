Field Reports OCaml I/F
=======================

はじめに
--------

このREADMEファイルでは，Field ReportsのOCaml I/Fについて記述しています。

Field Reports本体ならびにOCaml I/Fの詳しいインストール手順／使い方については，
同梱の「ユーザーズ・マニュアル(users-man.pdf)」を参照してください。また，Field
Reportsに関する最新情報は，弊社Webサイトを参照してください::

    http://field-works.co.jp/

機能説明
--------

OCamlからField ReportsのPDF帳票生成機能を利用することができます。

APIを通じて，以下の機能を提供します。

* Field Reportsのバージョンを取得する。

* ログ出力のレベルを設定する。

* レンダリング・パラメータのデフォルト値を設定する。

* PDFを生成し，結果をバイナリ文字列として受け取る。

* PDFを生成し，結果をファイルに出力する。

API概要
-------
::

    (** バージョン番号を取得します。*)
    val Field.Reports.reports_version : string

    (** ログ出力のレベルを設定します。
        有効な値の範囲は0〜4です:
         0: ログを出力しない
         1: ERRORログを出力する
         2: WARNログを出力する
         3: INFOログを出力する
         4: DEBUGログを出力する
        1以上の値を設定した場合，標準エラー出力にログを出力します（初期値：0）。*)
    val Field.Reports.set_log_level : int -> unit

    (** レンダリング・パラメータのデフォルト値を設定します。*)
    val Field.Reports.set_defaults : Field.Jsonwheel.Json_type.t -> unit

    (** JSONオブジェクトを元にPDFを生成します。*)
    val Field.Reports.pdf_of_json :
        Field.Jsonwheel.Json_type.json_type -> string

    (** JSON文字列を元にPDFを生成します。*)
    val Field.Reports.pdf_of_jsons : string -> string

    (** JSONオブジェクトを元にPDFを生成し，ファイルに出力します。*)
    val Field.Reports.write_pdf_from_json :
        Field.Jsonwheel.Json_type.json_type -> string -> unit

    (** JSON文字列を元にPDFを生成し，ファイルに出力します。*)
    val Field.Reports.write_pdf_from_jsons : string -> string -> unit

    (** JSON文字列をJSONオブジェクトへ変換します。*)
    val Field.Reports.json_of_string :
        string -> Field.Jsonwheel.Json_type.json_type

必要条件
--------

本モジュールをご利用頂くには，以下のソフトウェアが必要です。

Linux, Mac OS X
~~~~~~~~~~~~~~~

* OCaml 3.12.1

* Findlib

Windows
~~~~~~~

* OCaml 3.12.1（msvcビルド版）

インストール手順
----------------
Linux, Mac OS X
~~~~~~~~~~~~~~~

管理者権限で，以下のコマンドを実行してください::

    # make install

Windows
~~~~~~~

管理者権限で，ライブラリファイルをコピーしてください（環境変数OCMALLIBにOCaml
ライブラリが格納されているディレクトリが設定されているものとします）::

    > copy *.dll %OCAMLLIB%\stublibs
    > copy field.* lib*.a %OCAMLLIB%

ライセンス
----------

「ソフトウェア使用許諾契約書」をご参照ください。

